"""Mesin sketsa (port dari Sketcher.kt): arsir pensil searah bentuk (LIC), garis detail, kertas."""
from __future__ import annotations

from dataclasses import dataclass

import cv2
import numpy as np

from .common import box_blur, hash_rnd, logistic, rint, smoothstep as sm, to_rgba, zscore

INK_MAX = 0.90
LINE_W = 0.45
FLAT_WIDE = 1.6
FLAT_TOOTH = 0.7
FLAT_DIR = 0.85
TONE_SOFT = 1.25
FLAT_SOFT = 0.85
FLAT_SOFT_R = 1.5
POST_BLUR = 1


@dataclass
class SketchParams:
    mode: int = 3     # 0 pensil, 1 pensil berwarna, 2 garis tegas, 3 arsir, 4 arsir + AI, 5 arsir berwarna + AI
    blur: int = 40    # 0..100 ketebalan/kehalusan garis
    dark: int = 70    # 0..100 kegelapan
    color: int = 75   # 0..100 kekuatan warna
    grain: int = 55   # 0..100 tekstur kertas
    paper: int = 0    # 0 putih, 1 krem, 2 papan tulis, 3 transparan (PNG, hanya garis)


def render_hd(src: np.ndarray, p: SketchParams, ai_lines=None, upscaler=None, cartoon=None) -> np.ndarray:
    """Seperti render(), tapi foto kecil diperbesar dulu (mode arsir) supaya goresan tetap halus."""
    h, w = src.shape[:2]
    big = max(w, h)
    if p.mode < 3 or big >= 1400:
        return render(src, p, ai_lines, cartoon)
    work = src
    ai = False
    if big <= 650 and upscaler is not None:
        sr = upscaler(src)
        if sr is not None:
            work, ai = sr, True
    b2 = max(work.shape[:2])
    target = int(np.clip(b2, 1400, 1800)) if ai else 1400
    if b2 != target:
        f = target / b2
        work = cv2.resize(work, (rint(work.shape[1] * f), rint(work.shape[0] * f)), interpolation=cv2.INTER_AREA if f < 1 else cv2.INTER_CUBIC)
    return render(work, p, ai_lines, cartoon)


def render(src: np.ndarray, p: SketchParams, ai_lines=None, cartoon=None) -> np.ndarray:
    """src: RGBA/RGB uint8. ai_lines: fungsi(src_rgb)->float 0..255 (HxW) atau None. Hasil RGBA uint8."""
    src = to_rgba(src)
    h, w = src.shape[:2]
    rgb = src[..., :3].astype(np.float32)
    scale = max(w, h) / 900.0
    gray = np.floor((rgb[..., 0] * 299 + rgb[..., 1] * 587 + rgb[..., 2] * 114) / 1000.0)

    if p.mode == 6:
        return _cartoon2d(src, scale, p, cartoon)
    ln = None
    if p.mode >= 3:
        if p.mode == 5 and p.paper in (0, 1):
            v, ln = _hatch(gray, p, scale, True)
        else:
            v = _hatch(gray, p, scale)
        if p.mode >= 4 and ai_lines is not None:
            ai = ai_lines(src)
            if ai is not None:
                v = np.floor(v * (1.0 - 0.20 * (1.0 - ai / 255.0)))
    elif p.mode == 2:
        g = box_blur(gray, max(1, rint((1 + p.blur * 0.12) * scale)))
        gain = 1.5 + p.dark * 0.06
        gx = cv2.Sobel(g, cv2.CV_32F, 1, 0, ksize=3, borderType=cv2.BORDER_REPLICATE)
        gy = cv2.Sobel(g, cv2.CV_32F, 0, 1, ksize=3, borderType=cv2.BORDER_REPLICATE)
        v = 255 - np.minimum(255, (np.abs(gx) + np.abs(gy)) * gain / 2.0)
        v[0, :] = v[-1, :] = 255
        v[:, 0] = v[:, -1] = 255
    else:
        inv = box_blur(255 - gray, max(1, rint((2 + p.blur * 0.38) * scale)))
        gamma = 0.6 + p.dark / 100.0 * 1.4
        d = np.maximum(1.0, 256 - inv)
        t = np.minimum(255, gray * 256 / d) / 255.0
        v = np.clip(255.0 * t ** gamma, 0, 255)

    if p.mode == 5 and p.paper in (0, 1) and ln is not None:
        return _pencil_color(src, v, scale, p)

    colored = p.mode in (1, 5)
    kc = p.color / 100.0
    gr = p.grain / 100.0 * (0.5 if p.mode >= 3 else 1.0)
    idx = np.arange(h * w, dtype=np.int64).reshape(h, w)
    noise = ((idx.astype(np.uint32) * np.uint32(0x9E3779B1)) >> np.uint32(24)).astype(np.float32) / 255.0
    vv = v * (1.0 - gr * 0.25 * noise)

    if colored:
        lc = 255.0 * (1 - kc) + rgb * kc            # HxWx3
    else:
        lc = np.full((h, w, 3), 255.0, np.float32)

    out = np.empty((h, w, 4), np.uint8)
    if p.paper == 3:
        al = np.clip(np.floor(255.0 - vv), 0, 255)
        if colored:
            col = np.clip(np.floor(lc * 0.5), 0, 255)
        else:
            col = np.empty((h, w, 3), np.float32)
            col[...] = (20, 20, 24)
        out[..., :3] = col.astype(np.uint8)
        out[..., 3] = al.astype(np.uint8)
        return out

    if p.paper == 2:
        t = ((255.0 - vv) / 255.0)[..., None]
        base = np.array([43.0, 58.0, 51.0], np.float32)
        c = base + (lc - base) * t
    else:
        pc = np.array([245.0, 236.0, 215.0], np.float32) if p.paper == 1 else np.array([255.0] * 3, np.float32)
        c = vv[..., None] * lc / 255.0 * pc / 255.0
    out[..., :3] = np.clip(np.floor(c), 0, 255).astype(np.uint8)
    out[..., 3] = 255
    return out


# ------------------------------------------------------------------ arsir
def _flow_field(t: np.ndarray, scale: float):
    gx = np.zeros_like(t)
    gy = np.zeros_like(t)
    gx[1:-1, 1:-1] = t[1:-1, 2:] - t[1:-1, :-2]
    gy[1:-1, 1:-1] = t[2:, 1:-1] - t[:-2, 1:-1]
    r = max(2, rint(7 * scale))
    jxx = box_blur(gx * gx, r)
    jyy = box_blur(gy * gy, r)
    jxy = box_blur(gx * gy, r)
    ax = jxx - jyy
    ay = 2 * jxy
    tr = jxx + jyy + 150.0
    ang = 0.5 * np.arctan2(-ay / tr - 0.25, -ax / tr)
    return np.cos(ang).astype(np.float32), np.sin(ang).astype(np.float32)


def _flatness(tone: np.ndarray, scale: float) -> np.ndarray:
    gx = np.zeros_like(tone)
    gy = np.zeros_like(tone)
    gx[1:-1, 1:-1] = tone[1:-1, 2:] - tone[1:-1, :-2]
    gy[1:-1, 1:-1] = tone[2:, 1:-1] - tone[:-2, 1:-1]
    gm = np.floor(np.sqrt(gx * gx + gy * gy) * 4.0)
    gm = box_blur(gm, max(2, rint(3 * scale)))
    return 1.0 - sm(3.0, 12.0, gm / 4.0 * scale)


def _lic(noise: np.ndarray, fx: np.ndarray, fy: np.ndarray, steps: int, stp: float) -> np.ndarray:
    h, w = noise.shape
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    s = noise.copy()
    dx = fx * stp
    dy = fy * stp
    for k in range(1, steps + 1):
        ox = dx * k
        oy = dy * k
        ya = np.clip(yy + oy + 0.5, 0, h - 1).astype(np.int32)
        xa = np.clip(xx + ox + 0.5, 0, w - 1).astype(np.int32)
        s += noise[ya, xa]
        yb = np.clip(yy - oy + 0.5, 0, h - 1).astype(np.int32)
        xb = np.clip(xx - ox + 0.5, 0, w - 1).astype(np.int32)
        s += noise[yb, xb]
    return s / (2 * steps + 1)


def _detail_lines(gray: np.ndarray, scale: float) -> np.ndarray:
    def rr(sig):
        return max(1, rint(sig - 0.5))

    gd = box_blur(gray * 4.0, rr(0.9 * scale))
    dog1 = box_blur(gd, rr(0.9 * scale)) - box_blur(gd, rr(1.8 * scale))
    dog2 = box_blur(gd, rr(1.7 * scale)) - box_blur(gd, rr(3.4 * scale))
    gx = np.zeros_like(gd)
    gy = np.zeros_like(gd)
    gx[1:-1, 1:-1] = gd[1:-1, 2:] - gd[1:-1, :-2]
    gy[1:-1, 1:-1] = gd[2:, 1:-1] - gd[:-2, 1:-1]
    gm = box_blur(np.floor(np.sqrt(gx * gx + gy * gy)), rr(1.5 * scale))
    es = gm / 4.0 * scale
    gate = sm(5.0, 16.0, es)
    l1 = np.clip(-dog1 / 120.0, 0, 1) * 0.8
    l2 = np.clip(-dog2 / 150.0, 0, 1) * 0.5
    return np.clip(l1 + l2, 0, 1) * gate


def _hatch(gray: np.ndarray, p: SketchParams, scale: float, want_lines: bool = False):
    h, w = gray.shape
    n = h * w
    bl = box_blur(gray, max(1, rint(1.4 * scale - 0.5)))
    tone = np.clip(np.floor(gray + 0.3 * (gray - bl)), 0, 255)
    tone = np.floor(box_blur(tone, max(1, rint(0.6 * scale))))
    bl = box_blur(tone, max(2, rint(9 * scale - 0.5)))
    tone = np.clip(np.floor(tone + 0.3 * (tone - bl)), 0, 255)
    ti = tone.astype(np.int32)

    hist = np.bincount(ti.ravel(), minlength=256)
    cs = np.cumsum(hist)
    lo = min(255, int(np.searchsorted(cs, n * 0.01, side="left")))
    rcs = np.cumsum(hist[::-1])
    hi = 255 - min(255, int(np.searchsorted(rcs, n * 0.01, side="left")))
    if hi - lo < 32:
        lo, hi = 0, 255
    inv = 1.0 / (hi - lo)
    gamma = 1.0 / (0.55 + p.dark / 100.0 * 1.1)

    mt = float(np.clip(np.clip((tone - lo) * inv, 0, 1).mean(), 0.05, 0.95))
    ex = float(np.clip(np.log(0.58) / np.log(mt), 0.45, 1.0))
    tv = np.arange(256, dtype=np.float32)
    dlut = ((1.0 - np.clip((tv - lo) * inv, 0, 1) ** ex) ** gamma).astype(np.float32)

    fx, fy = _flow_field(tone, scale)
    flat = _flatness(tone, scale)

    yy, xx = np.mgrid[0:h, 0:w]
    cw = max(1, rint(FLAT_WIDE * scale))
    srcn = hash_rnd((yy // cw) * 100003 + (xx // cw) + 7)
    press = zscore(_lic(srcn, fx, fy, 12, max(1.0, scale)))
    srcn = hash_rnd(np.arange(n, dtype=np.int64).reshape(h, w) * 31 + 12345)
    fine = zscore(_lic(srcn, fx, fy, 9, max(1.0, scale * 0.8)))
    iso = np.floor(hash_rnd(np.arange(n, dtype=np.int64).reshape(h, w) * 17 + 99991) * 1023.0)
    iso = box_blur(iso, max(1, rint(FLAT_TOOTH * scale - 0.5)))
    mI = float(iso.mean())
    sdI = max(float(iso.std()), 1e-6)

    d = dlut[ti]
    pr = 0.5 + 0.22 * press
    dd = np.clip(d * (0.65 + 0.7 * pr), 0, 1)
    tooth = (1 - FLAT_DIR) * logistic((iso - mI) / sdI) + FLAT_DIR * logistic(fine)
    cov = np.clip((dd - 0.02 - tooth * 0.95) / 0.55 + 0.5, 0, 1) * sm(0.05, 0.35, d)
    sw = flat * (1.0 - sm(0.45, 0.80, d))
    dark = 0.55 * d ** 1.2 + 0.36 * cov * (1 - 0.30 * sw)
    dark = np.clip(dark, 0, 1) ** TONE_SOFT
    fxx = (xx - w * 0.5) / (w * 0.62)
    fyy = (yy - h * 0.45) / (h * 0.62)
    fade = 1.0 - 0.4 * sm(0.7, 1.5, fxx * fxx + fyy * fyy)
    dark = dark * fade
    v = np.clip(np.floor(255.0 * (1.0 - np.clip(dark, 0, 1) * INK_MAX)), 0, 255).astype(np.float32)

    vb = box_blur(v, max(1, rint(FLAT_SOFT_R * scale)))
    f = sw * FLAT_SOFT
    v = np.clip(np.floor(v + (vb - v) * f), 0, 255)
    if scale >= 1.0:
        k = np.array([1, 6, 1], np.float32) / 8.0
        for _ in range(POST_BLUR):
            v = cv2.sepFilter2D(v, -1, k, k, borderType=cv2.BORDER_REPLICATE)
            v = np.floor(v)

    ln = _detail_lines(gray, scale)
    m = ln > 0
    if m.any():
        fac = 1.0 - LINE_W * ln * (0.35 + 0.65 * (1.0 - d)) * fade
        v = np.where(m, np.clip(np.floor(v * fac), 0, 255), v)
    if want_lines:
        return v.astype(np.float32), ln
    return v.astype(np.float32)


# ------------------------------------------------------------------ gaya ilustrasi komik (Arsir Berwarna + AI)
# Peta kecerahan -> warna, diambil dari gambar referensi: bayangan hijau-hitam, tengah hijau zaitun redup, sorotan ocher krem.
_PALETTE_L = np.array([0, 9, 25, 45, 59, 71, 84, 102, 122, 143, 176, 216, 255], np.float32)
_PALETTE_RGB = np.array([[6, 7, 6], [10, 11, 8], [24, 27, 22], [42, 48, 43], [54, 62, 59], [65, 73, 69], [80, 88, 79],
                         [101, 106, 93], [123, 125, 107], [150, 145, 121], [188, 180, 152], [232, 215, 169],
                         [244, 234, 205]], np.float32)
_INK_RGB = np.array([20, 24, 20], np.float32)
_PAPER_RGB = {0: np.array([242, 236, 220], np.float32), 1: np.array([240, 228, 200], np.float32)}


def _comic_look(src: np.ndarray, gray: np.ndarray, v: np.ndarray, ln: np.ndarray, scale: float, p: SketchParams, cartoon=None) -> np.ndarray:
    """Foto digambar ulang ala kartun / graphic novel: bidang warna rata dari palet tetap, kontur tinta bersih dan tebal,
    arsiran jarang hanya di bayangan. Tekstur foto dibuang. Kekuatan warna = sedikit warna asli ikut (0 = palet murni)."""
    h, w = gray.shape
    rgb = src[..., :3]
    kc = p.color / 100.0 * 0.5

    # 1) Digambar ulang oleh model kartun AI (bila ada); cadangan: abstraksi mean-shift
    cart = cartoon(src) if cartoon is not None else None
    if cart is not None:
        sm_rgb = cart
        Lg = cv2.cvtColor(sm_rgb, cv2.COLOR_RGB2GRAY)
        Lg = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(6, 6)).apply(Lg)
    else:
        ws = 900.0 / max(w, h)
        small = cv2.resize(rgb, (max(2, int(w * ws)), max(2, int(h * ws))), interpolation=cv2.INTER_AREA) if ws < 1 else rgb
        sm_rgb = cv2.pyrMeanShiftFiltering(small, 7, 22, maxLevel=2)
        sm_rgb = cv2.bilateralFilter(sm_rgb, 0, 25, 6)
        Lg = cv2.cvtColor(sm_rgb, cv2.COLOR_RGB2GRAY)
        Lg = cv2.createCLAHE(clipLimit=2.6, tileGridSize=(6, 6)).apply(Lg)
        if small.shape[:2] != (h, w):
            Lg = cv2.resize(Lg, (w, h), interpolation=cv2.INTER_CUBIC)
            sm_rgb = cv2.resize(sm_rgb, (w, h), interpolation=cv2.INTER_CUBIC)
    t = Lg.astype(np.float32) / 255.0
    lo, hi = np.percentile(t, 1.0), np.percentile(t, 99.0)
    t = np.clip((t - lo) / max(hi - lo, 1e-3), 0, 1)
    t = t ** (0.80 + 0.5 * (1 - p.dark / 100.0))

    # 2) Pita nada rata (6 tingkat) dengan peralihan sempit -> kesan cat datar / cel shading
    nb = 6
    x = t * nb
    fl = np.floor(x)
    fr = x - fl
    tb = (fl + sm(0.40, 0.60, fr)) / nb
    t = np.clip(tb * (0.35 if cart is not None else 1.0) + t * (0.65 if cart is not None else 0.0), 0, 1)
    t = cv2.GaussianBlur(t, (0, 0), max(0.7, 0.6 * scale))

    lut = np.stack([np.interp(np.arange(256), _PALETTE_L, _PALETTE_RGB[:, c]) for c in range(3)], 1).astype(np.float32)
    lum_l = (0.299 * lut[:, 0] + 0.587 * lut[:, 1] + 0.114 * lut[:, 2])[:, None]
    lut = np.clip(lum_l + (lut - lum_l) * 1.45, 0, 255)
    col = lut[np.clip((t * 255).astype(np.int32), 0, 255)]
    if kc > 0:
        lum = (0.299 * sm_rgb[..., 0] + 0.587 * sm_rgb[..., 1] + 0.114 * sm_rgb[..., 2])[..., None].astype(np.float32)
        tint = col * (1 + (sm_rgb.astype(np.float32) - lum) / 255.0 * 1.2)
        col = col * (1 - kc) + np.clip(tint, 0, 255) * kc

    # 3) Kontur tinta: XDoG pada gambar yang sudah diratakan -> garis bersih, buang bintik, tebalkan
    g = cv2.GaussianBlur(Lg.astype(np.float32), (0, 0), max(1.0, 1.1 * scale))
    g2 = cv2.GaussianBlur(Lg.astype(np.float32), (0, 0), max(1.6, 1.9 * scale))
    d = (g - g2) / 255.0
    line = np.clip((-d - 0.004) * 55.0, 0, 1)
    m = (line > 0.5).astype(np.uint8)
    n_c, lab, stats, _ = cv2.connectedComponentsWithStats(m, connectivity=8)
    keep = np.zeros(n_c, bool)
    keep[1:] = stats[1:, cv2.CC_STAT_AREA] >= max(25, int(40 * scale * scale))
    m = keep[lab].astype(np.uint8)
    k = max(2, int(round(1.8 * scale)))
    m = cv2.dilate(m, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k)))
    contour = cv2.GaussianBlur(m.astype(np.float32), (0, 0), max(0.6, 0.5 * scale))
    # garis detail halus dari lapisan arsir (mata, alis, lipatan) ikut tipis
    contour = np.clip(np.maximum(contour, np.clip(ln * 1.3, 0, 1) * 0.55), 0, 1)

    # 4) Arsiran jarang diagonal, hanya di bayangan (bukan seluruh gambar)
    yy, xx = np.mgrid[0:h, 0:w]
    sp_ = max(5.0, 6.5 * scale)
    ph = ((xx + yy) / sp_) % 1.0
    stripes = (ph < 0.22).astype(np.float32)
    stripes = cv2.GaussianBlur(stripes, (0, 0), max(0.5, 0.45 * scale))
    shadow = sm(0.30, 0.12, t) * sm(0.02, 0.07, t)                     # bayangan sedang, bukan hitam pekat
    hatch = stripes * shadow * (0.35 + 0.35 * p.dark / 100.0)

    out = col * (1 - hatch[..., None]) + _INK_RGB * hatch[..., None]
    out = out * (1 - contour[..., None]) + _INK_RGB * contour[..., None]

    # 5) Kertas: butiran halus saja (tanpa noda)
    gr = p.grain / 100.0
    noise = hash_rnd(np.arange(h * w, dtype=np.int64).reshape(h, w) * 7 + 31)
    out = out * (1 + gr * 0.05 * (noise - 0.5)[..., None])
    res = np.empty((h, w, 4), np.uint8)
    res[..., :3] = np.clip(np.floor(out + 0.5), 0, 255).astype(np.uint8)
    res[..., 3] = 255
    return res


def _pencil_color(src: np.ndarray, v: np.ndarray, scale: float, p: SketchParams) -> np.ndarray:
    """Sketsa arsir pensil (sama seperti mode Arsir) di atas lapisan warna cat halus.
    Nada warna memakai palet tetap (zaitun-ocher) sehingga hasil seragam; 'Kekuatan warna' menambah warna asli foto."""
    h, w = v.shape
    rgb = src[..., :3]
    kc = p.color / 100.0 * 0.8
    # warna: ratakan seperti sapuan cat/pewarna air
    ws = 700.0 / max(w, h)
    small = cv2.resize(rgb, (max(2, int(w * ws)), max(2, int(h * ws))), interpolation=cv2.INTER_AREA) if ws < 1 else rgb
    sm_ = cv2.bilateralFilter(small, 0, 35, 8)
    sm_ = cv2.bilateralFilter(sm_, 0, 35, 8)
    sm_ = cv2.GaussianBlur(sm_, (0, 0), 2.0)
    if small.shape[:2] != (h, w):
        sm_ = cv2.resize(sm_, (w, h), interpolation=cv2.INTER_CUBIC)
    Lg = cv2.cvtColor(sm_, cv2.COLOR_RGB2GRAY).astype(np.float32)
    lo, hi = np.percentile(Lg, 1.5), np.percentile(Lg, 98.5)
    t = np.clip((Lg - lo) / max(hi - lo, 1.0), 0, 1) ** 0.9
    lut = np.stack([np.interp(np.arange(256), _PALETTE_L, _PALETTE_RGB[:, c]) for c in range(3)], 1).astype(np.float32)
    lum_l = (0.299 * lut[:, 0] + 0.587 * lut[:, 1] + 0.114 * lut[:, 2])[:, None]
    lut = np.clip(lum_l + (lut - lum_l) * 1.5, 0, 255)
    col = lut[np.clip((t * 255).astype(np.int32), 0, 255)]
    if kc > 0:
        lum = (0.299 * sm_[..., 0] + 0.587 * sm_[..., 1] + 0.114 * sm_[..., 2])[..., None].astype(np.float32)
        tint = col * (1 + (sm_.astype(np.float32) - lum) / 255.0 * 1.4)
        col = col * (1 - kc) + np.clip(tint, 0, 255) * kc
    paper = _PAPER_RGB.get(p.paper, _PAPER_RGB[0])
    # warna dibuat ringan supaya arsiran pensil tetap dominan, dan memudar ke kertas di tepi (seperti sketsa berwarna)
    yy, xx = np.mgrid[0:h, 0:w]
    fx = (xx - w * 0.5) / (w * 0.62)
    fy = (yy - h * 0.45) / (h * 0.62)
    edge = 1.0 - 0.85 * sm(0.55, 1.35, fx * fx + fy * fy)
    s_ = (0.72 * edge)[..., None]
    wash = paper * (1 - s_) + col * s_
    wash = wash + (255.0 - wash) * 0.10
    noise = ((np.arange(h * w, dtype=np.int64).reshape(h, w).astype(np.uint32) * np.uint32(0x9E3779B1)) >> np.uint32(24)).astype(np.float32) / 255.0
    gr = p.grain / 100.0 * 0.5
    vv = v * (1.0 - gr * 0.25 * noise)
    out = wash * (vv / 255.0)[..., None]
    res = np.empty((h, w, 4), np.uint8)
    res[..., :3] = np.clip(np.floor(out + 0.5), 0, 255).astype(np.uint8)
    res[..., 3] = 255
    return res


# ------------------------------------------------------------------ Kartun 2D (bidang warna rata + kontur tegas)
def _cartoon2d(src: np.ndarray, scale: float, p: SketchParams, cartoon=None) -> np.ndarray:
    """Foto -> kartun 2D: sedikit warna datar, tanpa gradasi/tekstur, kontur hitam tegas, area terang dibiarkan putih.
    p.blur = ketebalan kontur, p.dark = jumlah warna, p.color = kejenuhan warna."""
    h, w = src.shape[:2]
    rgb = src[..., :3]
    # 1) ratakan: model kartun AI (bila ada) lalu mean-shift kuat -> bidang besar tanpa tekstur
    base = cartoon(src) if cartoon is not None else None
    if base is None:
        base = rgb
    ws = 800.0 / max(w, h)
    sm_ = cv2.resize(base, (max(2, int(w * ws)), max(2, int(h * ws))), interpolation=cv2.INTER_AREA) if ws < 1 else base.copy()
    sm_ = cv2.pyrMeanShiftFiltering(sm_, 9, 32, maxLevel=2)
    sm_ = cv2.bilateralFilter(sm_, 0, 30, 7)
    hh, ww = sm_.shape[:2]

    # 2) kuantisasi warna (k-means di ruang Lab) -> hanya K warna datar
    K = int(np.clip(5 + p.dark // 20, 5, 10))
    lab = cv2.cvtColor(sm_, cv2.COLOR_RGB2LAB).astype(np.float32)
    pts = lab.reshape(-1, 3)
    sub = pts[:: max(1, len(pts) // 40000)]
    crit = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 25, 0.5)
    _, _, centers = cv2.kmeans(sub, K, None, crit, 3, cv2.KMEANS_PP_CENTERS)
    d = ((pts[:, None, :] - centers[None, :, :]) ** 2).sum(2)
    lbl = np.argmin(d, 1).astype(np.uint8).reshape(hh, ww)
    lbl = cv2.medianBlur(lbl, 7)                                    # buang bintik, sisakan bidang besar
    lbl = cv2.medianBlur(lbl, 5)

    # 3) warna tiap bidang: rata-rata asli, dibuat lebih cerah/jenuh seperti kartun; cluster sangat terang = putih (tak diwarnai)
    sat_boost = 0.85 + p.color / 100.0 * 0.75
    pal = np.zeros((K, 3), np.float32)
    for k in range(K):
        m = lbl == k
        pal[k] = sm_[m].mean(0) if m.any() else (255, 255, 255)
    hsv = cv2.cvtColor(pal[None].astype(np.uint8), cv2.COLOR_RGB2HSV)[0].astype(np.float32)
    hsv[:, 1] = np.clip(hsv[:, 1] * sat_boost, 0, 255)
    hsv[:, 2] = np.clip(hsv[:, 2] * 1.08 + 8, 0, 255)
    pal = cv2.cvtColor(hsv[None].astype(np.uint8), cv2.COLOR_HSV2RGB)[0].astype(np.float32)
    lum = pal @ np.array([0.299, 0.587, 0.114], np.float32)
    white = (lum > 205) & (hsv[:, 1] < 70)
    paper = _PAPER_RGB.get(p.paper, np.array([255.0, 255.0, 255.0], np.float32)) if p.paper == 1 else np.array([255.0] * 3, np.float32)
    pal[white] = paper
    flat = pal[lbl]
    if (hh, ww) != (h, w):
        flat = cv2.resize(flat, (w, h), interpolation=cv2.INTER_NEAREST)
        lbl_f = cv2.resize(lbl, (w, h), interpolation=cv2.INTER_NEAREST)
    else:
        lbl_f = lbl

    # 4) tinta komik: garis tegas dari gambar ASLI (bukan yang dihaluskan), bidang hitam solid, bayangan jarang
    g0 = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)
    g0 = cv2.bilateralFilter(g0, 7, 40, 5).astype(np.float32)           # buang tekstur halus, pertahankan tepi
    s1 = max(1.0, 1.0 * scale)
    G = lambda sg: cv2.GaussianBlur(g0, (0, 0), sg)                       # noqa: E731
    fine = ((G(s1 * 1.7) - G(s1)) / 255.0 > 0.011)                        # garis detail: mata, mulut, lipatan, tepi baju
    bold = ((G(s1 * 4.0) - G(s1 * 2.4)) / 255.0 > 0.014)                  # kontur besar: siluet, objek
    lines = (fine | bold).astype(np.uint8)
    n_c, lab_c, st, _ = cv2.connectedComponentsWithStats(lines, connectivity=8)
    keep = np.zeros(n_c, bool)
    keep[1:] = st[1:, cv2.CC_STAT_AREA] >= max(40, int(70 * scale * scale))   # garis putus-putus/bintik dibuang
    lines = keep[lab_c].astype(np.uint8)
    thick = int(round((0.55 + p.blur / 100.0 * 1.5) * scale))               # garis tipis (bawaan ~1 px pada foto 900 px)
    if thick >= 2:
        lines = cv2.dilate(lines, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (thick, thick)))
    # bidang hitam solid: area paling gelap (rambut, bayangan pekat, baju gelap)
    gm = cv2.GaussianBlur(g0, (0, 0), max(1.2, 1.5 * scale))
    thr_dark = np.percentile(gm, 14 + (p.dark // 10))
    spot = (gm < min(thr_dark, 70)).astype(np.uint8)
    spot = cv2.medianBlur(spot * 255, 2 * max(2, int(3 * scale)) + 1) > 127
    n_s, lab_s, st_s, _ = cv2.connectedComponentsWithStats(spot.astype(np.uint8), connectivity=8)
    ks = np.zeros(n_s, bool)
    ks[1:] = st_s[1:, cv2.CC_STAT_AREA] >= max(120, int(260 * scale * scale))
    spot = ks[lab_s]
    # bayangan jarang: garis miring tipis di area gelap-sedang (bukan arsiran padat)
    yy, xx = np.mgrid[0:h, 0:w]
    shade = (gm >= min(thr_dark, 70)) & (gm < np.percentile(gm, 32))
    stripes = (((xx + yy) / max(6.0, 8.0 * scale)) % 1.0 < 0.11) & shade
    def soft(m):
        a_ = cv2.GaussianBlur(m.astype(np.float32), (0, 0), max(0.45, 0.45 * scale))
        return np.clip((a_ - 0.25) * 1.7, 0, 1)[..., None]

    a_line, a_spot, a_hatch = soft(lines > 0), soft(spot), soft(stripes)

    # warna: tipis/sebagian di bawah tinta; Kekuatan warna 0 = abu-abu pensil di kertas putih
    op = float(np.clip(p.color / 60.0, 0, 1)) * 0.85
    base_col = paper * (1 - op) + flat * op
    c_hatch = np.array([172, 174, 180], np.float32)     # arsiran: abu-abu muda (lebih terang dari garis)
    c_spot = np.array([88, 90, 96], np.float32)         # bidang gelap: abu-abu grafit, bukan hitam pekat
    c_line = np.array([62, 64, 70], np.float32)         # garis sketsa: abu-abu pensil
    out = base_col * (1 - a_hatch) + c_hatch * a_hatch
    out = out * (1 - a_spot) + c_spot * a_spot
    out = out * (1 - a_line) + c_line * a_line
    res = np.empty((h, w, 4), np.uint8)
    res[..., :3] = np.clip(np.floor(out + 0.5), 0, 255).astype(np.uint8)
    res[..., 3] = 255
    return res
